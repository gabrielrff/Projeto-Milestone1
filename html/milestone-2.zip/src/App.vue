<template>
  <navBar></navBar>


  <router-view >

    

  </router-view>
  
  
  
 
  
</template>


<script>
import navBar from "./components/navbar.vue";

export default {
  components:{
    navBar
  }
  
}
</script>

<style>

</style>
